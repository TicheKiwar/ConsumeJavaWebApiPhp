package CrudJavaWeb;

public class api {
    private static String url = "http://localhost/SOA/controller/apiRest.php";

    public static String getApi() {
        return url;
    }
}
